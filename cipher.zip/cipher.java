import java.io.*;
import java.util.*;
class cipher{
public static final String letters = "abcdefghijklmnopqrstuvwxyz";
  public static String caesencrypt(String message, int key){
    message = message.toLowerCase();
    String ciphered = "";
    for(int e = 0; e < message.length(); e++){
      int chpos = letters.indexOf(message.charAt(e));
      int keyvalue = (key + chpos) % 26;
      char replace = letters.charAt(keyvalue);
      if(replace == ('b')){
        ciphered = ciphered + "  "; 
      }
      else {
      ciphered = ciphered + replace;
    }
    }
    return ciphered; 
  }
  public static String caesdecrypt(String message, int key){
    message = message.toLowerCase();
    String ciphered = "";
    for(int e = 0; e < message.length(); e++){
      int chpos = letters.indexOf(message.charAt(e));
      int keyvalue = (key + chpos) % 26;
      if(keyvalue < 0){
        keyvalue = letters.length() + keyvalue;
      }
      char replace = letters.charAt(keyvalue);
            if(replace == ('b')){
        ciphered = ciphered + "  "; 
      }
      else {
      ciphered = ciphered + replace;
    }
  }
    return ciphered; 
  }
  public static String asciiencrypt(String message){
    String ciphered = "";
    for(int e = 0; e < message.length(); e++){
     char ch = message.charAt(e);
     int asc = (int) ch; 
      ciphered = ciphered + asc + ""; 
    }
    return ciphered; 
  }
  public static String asciidecrypt(String m){
    String ciphered = "";
    String[] result = m.split(",");
    for(int e = 0; e < result.length; e++){
      int l = Integer.valueOf(result[e]);
      char c = (char) l; 
      ciphered = ciphered + c;
    }
    return ciphered; 
  }
}
