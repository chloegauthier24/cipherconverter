import java.io.*;
import java.util.*;
class Main {
  public static void main(String[] args) {
    int d = 0; 
    Scanner scan = new Scanner(System.in);
    Scanner sc = new Scanner(System.in);
    cipher ciph = new cipher(); 
    System.out.println("Do you want to use a Caesar cipher or ASCII?");
    String c = scan.next();
    c = c.toLowerCase();
    System.out.println("Do you want to decrypt or encrypt?");
    String o = scan.next();
    o = o.toLowerCase();
    System.out.println("What is your message? If you are decrypting ASCII, please enter each number with a comma between them.");
    String me = sc.nextLine();
    if(c.equals("caesar")){
      System.out.println("What is your key?");
      d = sc.nextInt(); 
    }
    if(c.equals("caesar") && o.equals("decrypt")){
      System.out.println(ciph.caesdecrypt(me, d));
    }
    else if(c.equals("caesar") && o.equals("encrypt")){
      System.out.println(ciph.caesencrypt(me, d));
    }
    else if(c.equals("ascii") && o.equals("decrypt")){
      System.out.println(ciph.asciidecrypt(me));
    }
    else if(c.equals("ascii") && o.equals("encrypt")){
      System.out.println(ciph.asciiencrypt(me));
    }
    else {
      System.out.println("Try again.");
    }
  } 
}